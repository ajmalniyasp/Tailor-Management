from django.urls import path
from . import views


app_name = "accounts"


urlpatterns = [
    path('', views.redirect_to_login, name='redirect_to_login'),
    path('dashboard/', views.home_page, name='home_page'),
    path("tailor/admin/dashboard/", views.admin_dashboard, name="admin_dashboard"),
    path("staff/dashboard/", views.staff_dashboard, name="staff_dashboard"),
    path("customer/dashboard/", views.customer_dashboard, name="customer_dashboard"),

    path('register/', views.CustomRegistrationView.as_view(), name='register'),
    path('login/', views.CustomLoginView.as_view(), name='account_login'),
    path('logout/', views.logout, name='logout'),

    path('forgot_password/', views.forgot_password, name='forgot_password'),
    path('reset_password_validate/<uidb64>/<token>/', views.reset_password_validate, name='reset_password_validate'),
    path('reset_password/', views.reset_password, name='reset_password'),

]
