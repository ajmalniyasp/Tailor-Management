from django.contrib.auth import login, authenticate
from django.core.signing import loads, BadSignature
from django.shortcuts import render, redirect
from django.views import View
from .models import User
from .forms import CustomSignupForm, CustomLoginForm
from django.contrib import messages, auth
from allauth.account.models import EmailAddress
from allauth.account.utils import send_email_confirmation
from django.contrib.auth.decorators import login_required
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from .utils import send_verification_email
from django.contrib.auth.tokens import default_token_generator
from django.http import HttpResponse
from django.core.exceptions import PermissionDenied

def role_required(allowed_roles=[]):

    def decorator(view_func):
        def wrapper(request, *args, **kwargs):
            if request.user.is_authenticated:
                if request.user.get_role() in allowed_roles:
                    return view_func(request, *args, **kwargs)
            raise PermissionDenied
        return wrapper
    return decorator


def redirect_to_login(request):
    return redirect('accounts:account_login')


def forgot_password(request):
    if request.method == 'POST':
        email = request.POST['email']

        if User.objects.filter(email=email).exists():
            user = User.objects.get(email__exact=email)

            # send reset password email
            mail_subject = 'Reset your password'
            email_template = 'accounts/email/reset_password_email.html'
            send_verification_email(request, user, mail_subject, email_template)

            messages.success(request, 'Password reset link has sent to your email address')
            return redirect('accounts:account_login')
        else:
            messages.error(request, 'Account does not exist!')
            return redirect('accounts:forgot_password')

    return render(request, 'accounts/forgot_password.html')


def reset_password_validate(request, uidb64, token):
    # validate the user by decoding the user and pk
    try:
        uid = urlsafe_base64_decode(uidb64).decode()
        user = User._default_manager.get(pk=uid)
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    if user is not None and default_token_generator.check_token(user, token):
        request.session['uid'] = uid
        messages.info(request, 'Please reset your password')
        return redirect('accounts:reset_password')
    else:
        messages.error(request, 'This link has been expired')
        return redirect('accounts:home_page')


def reset_password(request):
    if request.method == 'POST':
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']

        if password == confirm_password:
            pk = request.session.get('uid')
            user = User.objects.get(pk=pk)
            user.set_password(password)
            user.is_active = True
            user.save()
            messages.success(request, 'Password reset successful')
            return redirect('accounts:account_login')
        else:
            messages.error(request, 'Password not match!')
            return redirect('accounts:reset_password')
    return render(request, 'accounts/reset_password.html')


class CustomRegistrationView(View):
    def get(self, request):
        if request.user.is_authenticated:
            return redirect('accounts:home_page')
        form = CustomSignupForm()

        return render(request, 'accounts/register.html', {'form': form})

    def post(self, request):
        form = CustomSignupForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.email = form.cleaned_data.get('email')
            # user.role = form.cleaned_data.get('role', 1)
            user.save()
            send_email_confirmation(request, user)  # Email verification with allauth
            messages.success(request, "Registration successful. Please verify your email.")
            return redirect('accounts:account_login')
        return render(request, 'accounts/register.html', {'form': form})


class CustomLoginView(View):
    def get(self, request):
        if request.user.is_authenticated:
            return redirect('accounts:home_page')
        form = CustomLoginForm()
        return render(request, 'accounts/login.html', {'form': form})

    def post(self, request):
        form = CustomLoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            user = authenticate(request, email=email, password=password)

            # Check if the user's email is verified
            if user is not None:
                email_address = EmailAddress.objects.filter(user=user, email=user.email).first()
                if email_address and email_address.verified:
                    login(request, user)


                    if user.get_role() == "Admin":
                        return redirect("accounts:admin_dashboard")
                    elif user.get_role() == "Staff":
                        return redirect("accounts:staff_dashboard")
                    elif user.get_role() == "Customer":
                        return redirect("accounts:customer_dashboard")
                    else:
                        return redirect('accounts:home_page')  # Redirect to a success page or home page

                else:
                    messages.error(request, "Please verify your email before logging in.")
            else:
                messages.error(request, "Invalid credentials. Please try again.")
        return render(request, 'accounts/login.html', {'form': form})


@login_required
def logout(request):
    auth.logout(request)
    messages.info(request, 'Logout successfully')
    return redirect('accounts:account_login')


@login_required
def home_page(request):
    return render(request, 'index.html', )


@login_required
# @role_required(["Admin"])
def admin_dashboard(request):
    return render(request, "accounts/dashboard/admin_dashboard.html")


@login_required
# @role_required(["Staff"])
def staff_dashboard(request):
    return render(request, "accounts/dashboard/staff_dashboard.html")


@login_required
@role_required(["Customer"])
def customer_dashboard(request):
    return render(request, "accounts/dashboard/customer_dashboard.html")