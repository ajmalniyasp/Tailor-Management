import datetime
from django.db import connection
from django.contrib import admin
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType
from django import forms
from . functions import get_auto_id
from django.shortcuts import redirect
from django.contrib import messages

from foundations.models import Languages, BaseModel


class BaseAdminView(admin.ModelAdmin):
    list_per_page = 50
    prepopulated_fields = {'slug': ('name',)}
    list_display = ('id', 'auto_id', 'is_deleted', 'is_active', )
    list_display_links = ('id', )
    ordering = ('auto_id', )
    list_filter = ('created_by', 'is_deleted', 'is_active', 'language')
    search_fields = ('id', )
    readonly_fields = ('id', 'created_at', 'updated_at')
    filter_horizontal = ()
    fieldsets = (
        ('Base Information', {
            'fields': (
                'auto_id', 'created_by', 'updated_by', 'deleted_by', 'created_at', 'updated_at', 'deleted_at',
                'language',
            ),
            'classes': ('collapse',),
        }),
        ('Status', {
            'fields': ('is_deleted', 'is_active', ),
            'classes': ('collapse',),
        }),
    )
    actions = ('soft_delete_selected', 'undelete_selected')

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        if obj is None:
            auto_id = get_auto_id(self.model)
            form.base_fields['auto_id'].initial = auto_id
            form.base_fields['created_by'].initial = request.user
            form.base_fields['updated_by'].initial = request.user
        # MAKE THE AUTO_ID, CREATED_BY, AND UPDATED_BY FIELDS READ-ONLY
        # for field_name in ['auto_id', 'created_by', 'updated_by']:
        #     form.base_fields[field_name].widget.attrs['readonly'] = True

        # Make fields readonly if user has change permissions
        if self.has_change_permission(request, obj):
            for field_name in ['auto_id', 'created_by', 'updated_by']:
                if field_name in form.base_fields:
                    form.base_fields[field_name].widget.attrs['readonly'] = True
        else:
            for field_name in ['auto_id', 'created_by', 'updated_by']:
                if field_name in form.base_fields:
                    form.base_fields[field_name].widget = forms.HiddenInput()

        return form

    def change_view(self, request, object_id, form_url='', extra_context=None):
        if not self.has_change_permission(request):
            messages.error(request, "You do not have permission to edit this item.")
            return redirect(request.META.get('HTTP_REFERER', 'admin:index'))
        return super().change_view(request, object_id, form_url, extra_context)

    def get_actions(self, request):
        actions = super().get_actions(request)

        # Remove soft delete and undelete actions if the user does not have 'delete' permissions
        if not self.has_delete_permission(request):
            if 'soft_delete_selected' in actions:
                del actions['soft_delete_selected']
            if 'undelete_selected' in actions:
                del actions['undelete_selected']

        return actions

    def soft_delete_selected(self, request, queryset):
        # CUSTOM ADMIN ACTION TO SOFTLY DELETE SELECTED ITEMS
        queryset.update(
            is_deleted=True, deleted_by=request.user,
            deleted_at=datetime.datetime.utcnow().isoformat('T', 'seconds') + "Z"
        )

    soft_delete_selected.short_description = "Soft delete selected items"

    def undelete_selected(self, request, queryset):
        # CUSTOM ADMIN ACTION TO UNDELETE SELECTED ITEMS
        queryset.update(
            is_deleted=False, updated_by=request.user,
            updated_at=datetime.datetime.utcnow().isoformat('T', 'seconds') + "Z"
        )

    undelete_selected.short_description = "Undelete selected items"


class LanguagesAdminView(admin.ModelAdmin):
    model = Languages
    list_display = ('code', 'name')
    ordering = ('code', 'name')
    search_fields = ('code', 'name')


admin.site.register(Languages, LanguagesAdminView)
